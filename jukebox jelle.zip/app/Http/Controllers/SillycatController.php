<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SillycatController extends Controller
{
    public function Sillycat(){
        return view('Sillycat');
    }
}
