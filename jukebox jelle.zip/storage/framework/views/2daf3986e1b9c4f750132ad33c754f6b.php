<?php $__env->startSection("content"); ?>

    <h1 class="text-3xl text-red-600"> hallo <?php echo e(Auth::user()->name ?? 'gebruiker'); ?>! welkom op mijn silly pagina</h1>
    <br><br>
    <p> welkom op de meest silly pagina van het hele internet.</p>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerStyle'); ?>

    fixed bottom-0

<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/hello.blade.php ENDPATH**/ ?>