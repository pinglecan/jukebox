<?php $__env->startSection("content"); ?>

    <form action="/playlist/storeTemp" method="POST">
        <?php echo csrf_field(); ?>
        <label class="items-center text-orange-400 text-2xl" for="name">Maak een playlist:</label> <br> <br>
        <input class="text-gray-600 rounded-lg" type="text" name="playlistName" placeholder="playlist naam...">
        <?php $__errorArgs = ['playlistName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <br><br>
        <input class="text-gray-600 rounded-lg" type="text" name="playlistDescription" placeholder="playlist description..." >

        <br><br>
        <input class="text-green-400 hover:bg-amber-50 p-1 duration-200 hover:cursor-pointer hover:border-gray-700 hover:rounded-lg " type="submit" value="Maak playlist">
    </form>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerStyle'); ?>

    fixed bottom-0

<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/playlist/TempPlaylist.blade.php ENDPATH**/ ?>