<?php $__env->startSection("content"); ?>

    <h1 class="text-red-600 font-bold text-3xl">sick ass song pagina</h1>
    <?php if(session("tempSongs")): ?>
    <p>this is the amount of songs selected: <?php echo e(count(session("tempSongs"))); ?></p>
    <?php endif; ?>
    <br><br>
    <a class="hover:bg-amber-50 hover:border-gray-700 hover:rounded-lg p-1 duration-200 text-blue-300"
       href="/songs/create">Create a song</a>
    <br><br>
    <ul>
        <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <br>
            <li class="text-green-500">
                <a href="/songs/view/<?php echo e($song->id); ?>">
                <?php echo e($song->name); ?>-<?php echo e($song->genre?->name); ?>

                     </a>
                <a class="text-sky-600" href="/songs/addToTempPlaylist/<?php echo e($song->id); ?>">add to temporary playlist</a>
            </li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerStyle'); ?>

    fixed bottom-0

<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/songs/index.blade.php ENDPATH**/ ?>