<script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<?php $__env->startSection('content'); ?>

    <h1 class="text-red-600 font-bold text-3xl"><?php echo e($playlist->name); ?></h1>
    <br>
    <h3 class="text-red-500 font-bold"><?php echo e($playlist->description); ?></h3>
    <br>
    <a href="<?php echo e(route("playlist.edit",$playlist)); ?>" class="text-blue-400">Edit playlist</a>
    <br>
    <p>Total Duration: <?php echo e(gmdate('i:s', $totalDuration)); ?></p>
    <br>
    <?php $__currentLoopData = $playlist->songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <a class="text-white" href="/songs/view/<?php echo e($song->id); ?>">- <?php echo e($song->name); ?></a>
        <form action="/playlist/<?php echo e($playlist->id); ?>/removesong/<?php echo e($song->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="text-red-800" type="submit">Remove song</button>
        </form>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <form action="/playlist/addsong/<?php echo e($playlist->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <select name="selectedSong" class="song-select-input">
            <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value='<?php echo e($song->id); ?>'><?php echo e($song->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br><br>

        <input
            class="text-green-400 hover:bg-amber-50 p-1 duration-200 hover:cursor-pointer hover:border-gray-700 hover:rounded-lg "
            type="submit" value="add song">

    </form>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerStyle'); ?>

    fixed bottom-0

<?php $__env->stopPush(); ?>


<script>
    $(document).ready(function () {
        $('.song-select-input').select2();
    });

</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/playlist/show.blade.php ENDPATH**/ ?>