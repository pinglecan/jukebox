<img src="./img/silly-remove.png" width="60%" height="60%" class="flex justify-center items-center ">





<?php /**PATH C:\xampp\htdocs\jukebox\resources\views/components/application-logo.blade.php ENDPATH**/ ?>