<?php $__env->startSection('content'); ?>

    <h1 class="text-red-600 font-bold text-3xl" ><?php echo e($song->name); ?></h1>
    <br>
    <h2 class="text-red-500 text-xl " >this song is made by: <?php echo e($song->artist); ?></h2>
    <p><?php echo e(gmdate("i:s", $song->duration)); ?></p>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerStyle'); ?>

    fixed bottom-0

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/songs/view.blade.php ENDPATH**/ ?>