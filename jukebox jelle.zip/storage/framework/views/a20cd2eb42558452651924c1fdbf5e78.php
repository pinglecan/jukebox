<?php $__env->startSection("content"); ?>
    <h1 class="text-red-600 font-bold text-3xl">sick ass genres pagina</h1>
    <br><br>
    <a class="hover:bg-amber-50 hover:border-gray-700 hover:rounded-lg p-1 duration-200 text-blue-300"
       href="/genres/create">create</a> <br>
    <h2 class="text-red-500"> Hier is de lijst met alle genres en het aantal liedjes met deze genre </h2>

    <ul>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <br>
            <li class="text-green-500">
                <?php echo e($genre->name); ?>-<?php echo e($genre->songs->count()); ?>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/genres/index.blade.php ENDPATH**/ ?>