<?php $__env->startSection("content"); ?>

    <?php if(Auth::check()): ?>
        <h1 class="text-red-600 font-bold text-3xl">Hier staan je playlists <?php echo e(Auth::user()->name); ?></h1>
    <?php else: ?>
        <h1 class="text-red-600 font-bold text-3xl">Hier staan je playlists</h1>
    <?php endif; ?>

    <br>
    <a class="hover:bg-amber-50 hover:border-gray-700 hover:rounded-lg p-1 duration-200 text-blue-300"
       href="/playlist/create">Create your playlist</a>

    <ul>
        <?php if(!session()->has('tempPlaylist')): ?>
            <a class="text-white" href="<?php echo e(route("playlist.TempPlaylist")); ?>">Turn temporary playlist into actual playlist</a>
        <?php endif; ?>

        <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($playlist->user_id == Auth::user()->id): ?>
            <br>
            <li class="text-green-500">
                <a href="/playlist/view/<?php echo e($playlist->id); ?>">
                    <?php echo e($playlist->name); ?>

                </a>
            </li>
                <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('footerStyle'); ?>

    fixed bottom-0

<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/playlist/index.blade.php ENDPATH**/ ?>