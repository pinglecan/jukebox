    

    <?php $__env->startSection("content"); ?>
        <h1 class="text-red-600 font-bold text-3xl">:3</h1>
        <div class="flex flex-col justify-center items-center min-h-screen">
            <img src="img/how_boys.gif"
                 alt="how boys who use :3 want to be held">
        </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startPush('footerStyle'); ?>

        fixed bottom-0

    <?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/Sillycat.blade.php ENDPATH**/ ?>