<?php $__env->startSection("content"); ?>

    <h1 class="text-white text-4xl mb-20">Fucking coole sesion pagina</h1>
    <a class="text-white" href="<?php echo e(route('session.add')); ?>"> add to sesion </a>
    <br>
    <a class="text-white" href="<?php echo e(route("session.remove")); ?>"> remove from session </a>

    <br><br>

    <p class="text-white"><?php echo e(var_dump(session('name'))); ?></p>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('footerStyle'); ?>

    fixed bottom-0

<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jukebox\resources\views/session/index.blade.php ENDPATH**/ ?>