    @extends("layouts.master")

    @section("content")
        <h1 class="text-red-600 font-bold text-3xl">:3</h1>
        <div class="flex flex-col justify-center items-center min-h-screen">
            <img src="img/how_boys.gif"
                 alt="how boys who use :3 want to be held">
        </div>
    @endsection


    @push('footerStyle')

        fixed bottom-0

    @endpush

